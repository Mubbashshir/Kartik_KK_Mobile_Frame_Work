﻿namespace AppiumEAFramework.Base
{
    public class BaseStep : BasePage
    {

    }
}

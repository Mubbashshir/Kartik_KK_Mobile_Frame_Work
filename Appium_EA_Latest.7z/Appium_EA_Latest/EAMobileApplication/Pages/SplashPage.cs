﻿using AppiumEAFramework.Base;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Support.PageObjects;

namespace EAMobileApplication.Pages
{
    class SplashPage : BasePage
    {
        public AppiumWebElement btnSkip => AppiumDriver.FindElementByXPath("//ion-button[text()='Skip']");

        internal HomePage SkipWelcome()
        {
            btnSkip.Click();
            return GetInstance<HomePage>();
        }



    }
}

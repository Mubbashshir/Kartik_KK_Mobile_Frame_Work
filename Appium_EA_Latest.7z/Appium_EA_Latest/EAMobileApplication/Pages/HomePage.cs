﻿using System.Threading;
using AppiumEAFramework.Base;
using OpenQA.Selenium.Appium;

namespace EAMobileApplication.Pages
{
    class HomePage : BasePage
    {
        public AppiumWebElement btnMenu => AppiumDriver.FindElementByXPath("//ion-menu-button");

        public AppiumWebElement menuLogin => AppiumDriver.FindElementByXPath("//ion-label[text()=' Login ']");

        public AppiumWebElement menuLogout => AppiumDriver.FindElementByXPath("//ion-label[text()=' Logout ']");

        public AppiumWebElement menuSchedule => AppiumDriver.FindElementByXPath("//ion-label[text()=' Schedule ']");

        public AppiumWebElement menuSpeakers => AppiumDriver.FindElementByXPath("//ion-label[text()=' Speakers ']");

        public AppiumWebElement lblHomePageHeader => AppiumDriver.FindElementByXPath("//ion-title[text()='Schedule']");

        public AppiumWebElement tabSpeakers => AppiumDriver.FindElementByXPath("//ion-label[text()='Speakers']");

        internal bool IsLogoutExist() => menuLogout.Displayed;




        public bool IsSchedulePage()
        {
            Thread.Sleep(5000);
            return lblHomePageHeader.Displayed;
        }


        public LoginPage ClickLogin()
        {
            menuLogin.Click();
            return GetInstance<LoginPage>();
        }

        public void ClickBreadCrumb()
        {
            btnMenu.Click();
        }

    }
}

﻿using AppiumEAFramework.Base;
using OpenQA.Selenium.Appium;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace EAMobileApplication.Pages
{
    public class NativeAppPage : BasePage
    {

        AppiumWebElement txtEmail => AppiumDriver.FindElementByAccessibilityId("email");

        AppiumWebElement txtPassword => AppiumDriver.FindElementByAccessibilityId("password");

        AppiumWebElement picker => AppiumDriver.FindElementByAccessibilityId("picker");

        AppiumWebElement pickerItem => AppiumDriver.FindElementById("android:id/text1");


        public void Login(Table table)
        {
            DriverFactory.Instance.WaitForElement(txtEmail);
            dynamic data = table.CreateDynamicInstance();
            txtEmail.SendKeys((string)data.Email);
            txtPassword.SendKeys((string)data.Password);
        }

        public void SelectPicker()
        {
            picker.Click();
            pickerItem.Click();
        }

    }
}

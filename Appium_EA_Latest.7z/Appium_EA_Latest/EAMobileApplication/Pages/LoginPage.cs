﻿using System.Threading;
using AppiumEAFramework.Base;
using OpenQA.Selenium.Appium;

namespace EAMobileApplication.Pages
{
    class LoginPage : BasePage
    {

        AppiumWebElement txtEmail => AppiumDriver.FindElementByXPath("//ion-input[@ng-reflect-name='username']/input");

        AppiumWebElement txtPassword => AppiumDriver.FindElementByXPath("//ion-input[@ng-reflect-name='password']/input");

        AppiumWebElement btnLogin => AppiumDriver.FindElementByXPath("//ion-button[text()='Login']");

        internal void Login(string email, string password)
        {
            Thread.Sleep(2000);
            txtEmail.SendKeys(email);
            txtPassword.SendKeys(password);
            AppiumDriver.HideKeyboard();
        }

        internal HomePage ClickLoginIn()
        {
            btnLogin.Click();
            return GetInstance<HomePage>();
        }

        public bool IsLoginPageExist()
        {
            return txtEmail.Displayed;
        }

    }
}
